import './Component.css';
function Component(props){
    return(
        <div className="component">
            <input type="text" onChange={props.value}/>
            
        </div>
    );
}
export default Component;