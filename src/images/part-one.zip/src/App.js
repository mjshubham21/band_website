import { useState } from 'react';
import './App.css';
import Component from './Component';

function App() {
 const[data,setdata] = useState();
 function getData(e){
      setdata(e.target.value);
 }


  return (
    <div className="App">
      <p>{data}</p>
      <Component value={getData}/>
    </div>
  );
}

export default App;
